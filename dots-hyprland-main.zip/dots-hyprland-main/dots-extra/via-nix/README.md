This folder contains tweakd configs when --via-nix is specified.
