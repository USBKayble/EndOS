# This script is meant to be sourced.
# It's not for directly running.

# shellcheck shell=bash

try rm "${FIRSTRUN_FILE}"
