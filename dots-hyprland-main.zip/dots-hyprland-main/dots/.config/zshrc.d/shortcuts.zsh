# Created by newuser for 5.9

bindkey '^H' backward-kill-word 
bindkey '^Z' undo
